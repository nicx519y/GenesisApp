// Generated from confirmed observations. Business expectations live in assertions.yaml.
export default async function test(runtime) {
  await runtime.step("s1");
  await runtime.step("s2");
  await runtime.step("s3");
  await runtime.step("s4");
  await runtime.step("s5");
}
