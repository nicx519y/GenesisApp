# MiniPhone 音乐播放与暂停验收

已有 World、已有歌曲的最小播放/暂停路径

前提：手机已登录；可使用已有 World、角色与歌曲。用户已允许本次 Worldo 验收截图发给 Codex 模型。保留账号和缓存；不要创建内容。

1. 进入第一个已有 World
   依据：用户允许选择现有列表第一个 World；当前页面树提供唯一描述。
   断言：{"source":"ui","target":{"kind":"description","value":"Spoiled by the Seven Archons&#10;Tick 18-17 · 142 Messages&#10;9-26 16:37&#10;冰墓再无门，众神却还守着那截已经化灰的残红不肯退开。&#10;xiaoyi yaohfjfjf&#10;· 另有 1 位玩家","x":0,"y":0},"property":"exists","operator":"equals","expected":"false","timeoutMs":15000,"sampleMs":500}

2. 打开 MiniPhone
   依据：已进入已有 World，页面提供唯一的迷你手机入口。
   断言：{"source":"ui","target":{"kind":"description","value":"開啟迷你手機，0 則未讀訊息&#10;13:25","x":0,"y":0},"property":"exists","operator":"equals","expected":"false","timeoutMs":10000,"sampleMs":500}

3. 打开 MiniPhone 音乐播放器
   依据：当前音乐卡片提供唯一语义入口，进入播放器后继续验证播放与暂停。
   断言：{"source":"ui","target":{"kind":"description","value":"播放","x":0,"y":0},"property":"exists","operator":"equals","expected":"true","timeoutMs":10000,"sampleMs":500}

4. 播放歌曲并验证系统音轨 started
   依据：播放器中存在唯一“播放”控件；当前音轨为 none，需实际播放并验证系统音轨状态。
   断言：{"source":"audio","target":{"kind":"description","value":"","x":0,"y":0},"property":"text","operator":"equals","expected":"started","timeoutMs":15000,"sampleMs":500}

5. 暂停歌曲并验证系统音轨 paused
   依据：播放断言失败，不能用界面进度代替系统音轨证据；按原目标暂停并保持暂停。
   断言：{"source":"audio","target":{"kind":"description","value":"","x":0,"y":0},"property":"text","operator":"equals","expected":"paused","timeoutMs":15000,"sampleMs":500}

覆盖限制：
- 播放状态 started 未验证通过；界面播放状态不能代替系统音轨证据。
